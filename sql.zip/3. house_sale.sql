use `dundins`;
delete from housesale;
INSERT INTO housesale
(aptCode, title, content, dealAmount, floor, dealYear, dealMonth, dealDay, area, room, userid)
VALUES (11110000000002,'♠보증금조절 가능 가성비甲♠넓은 역세권 깔끔한 원룸♠권유',
'# 주차비 별도
# 보증금 조절 가능

★ 100% 실제 매물 답사완료
(100% checked by my own eyes)

☆ 방이 어둡지 않고  방 사이즈 준수함
( extremely well lighted with super big room size )

★인근편의 공간 확보 깔끔함
(veranda place is very neat and well prepared)

☆ 남녀노소 누구나 좋아할 집
(men and women of all ages will love this house)

★ 이쁘고 아늑한 집
(beautiful and cozy house)',
'월세 3,000/75','4층',2022,11,24,'서울시 강남구 도곡동',1,'ssafy');
INSERT INTO housesale
(aptCode, title, content, dealAmount, floor, dealYear, dealMonth, dealDay, area, room, userid)
VALUES (11110000000002,'★★★선릉역 5분 통베란다2 있는 넓은 3룸★★★',
'◈ 매물 위치 ◈

  * 2호선 수인분당선 선릉역 도보 5분.

◈ 매물 구조 ◈

  * 방3 화장실2 통베란다2.

◈ 매물 특징 ◈

  * 보증금 :  4억5천만,   관리비: 10만원(수도요금 포함)

  * 운동장 통베란다,  살림 많은 가족 추천함.

  * 임차인 거주중으로 이사일 협의. 

  * 보증금 조정 가능함. 주차 어려움.
',
'전세 4억 5,000','3층',2022,11,24,'서울시 강남구 역삼동',3,'ssafy');
INSERT INTO housesale
(aptCode, title, content, dealAmount, floor, dealYear, dealMonth, dealDay, area, room, userid)
VALUES (11110000000002,'테라스가 있는 언주역 도보5분내외 초역세권 신축,첫입주!!',
'* 언주역 직선거리300미터 내외의 신축 첫입주입니다
*가전옵션이 풀 빌트인되어 공간활용이 좋습니다
*심플한 인테리어와 뉴트럴한 컬러로 디자인하시기 좋으며 1인가구및 신혼부부에게 추천드립니다
*어닝이 설치된 8평의 서비스면적인 중형 테라스가 있어 반려동물은 물론 다양하게 활용가능하십니다
*전세대출가능하며 최상의 컨디션에서 거주하실 수 있습니다',
'전세 5억 3,800','6층',2022,11,24,'서울시 강남구 논현동',2,'ssafy');
INSERT INTO housesale
(aptCode, title, content, dealAmount, floor, dealYear, dealMonth, dealDay, area, room, userid)
VALUES (11110000000002,'♠보증금조절 가능 가성비甲♠넓은 역세권 깔끔한 원룸♠권유',
'# 주차비 별도
# 보증금 조절 가능

★ 100% 실제 매물 답사완료
(100% checked by my own eyes)

☆ 방이 어둡지 않고  방 사이즈 준수함
( extremely well lighted with super big room size )

★인근편의 공간 확보 깔끔함
(veranda place is very neat and well prepared)

☆ 남녀노소 누구나 좋아할 집
(men and women of all ages will love this house)

★ 이쁘고 아늑한 집
(beautiful and cozy house)',
'전세 2억 5,000','4층',2022,11,24,'서울시 강남구 신사동',1,'ssafy');
INSERT INTO housesale
(aptCode, title, content, dealAmount, floor, dealYear, dealMonth, dealDay, area, room, userid)
VALUES (11110000000004,'거실 넓은 올 수리한 주택겸 사무실 같은 투룸 전세~~',
'관리비 : 10만원
포함 : 없음
별도 : 전기, 가스, 수도, 인터넷, 티비',
'월세 3,000/75','5층',2022,11,24,'서울시 강남구 도곡동',2,'ssafy');
INSERT INTO housesale
(aptCode, title, content, dealAmount, floor, dealYear, dealMonth, dealDay, area, room, userid)
VALUES (11110000000005,'💚학동역 도보3분 💚 전세자금대출가능💚 대리석바닥💚',
'관리비 : 10만원
포함 : 인터넷,티비
별도 : 전기, 가스, 수도',
'전세 3억 4,000','5층',2022,11,24,'서울시 강남구 논현동',2,'ssafy');
INSERT INTO housesale
(aptCode, title, content, dealAmount, floor, dealYear, dealMonth, dealDay, area, room, userid)
VALUES (11110000000006,'💕실13평💕신축2년차 풀옵션 . 고품격HOUSE💕',
'관리비 : 7만원
포함 : 없음
별도 : 전기, 가스, 수도, 인터넷, 티비',
'전세 3억 1,000','5층',2022,11,24,'서울시 강남구 논현동',2,'ssafy');
INSERT INTO housesale
(aptCode, title, content, dealAmount, floor, dealYear, dealMonth, dealDay, area, room, userid)
VALUES (11110000000007,'★★★언주역 8분 풀옵션 2룸 전세★★★',
'◈ 매물 위치 ◈

* 9호선 언주역 도보 8분.

◈ 매물 구조 ◈

* 방2 화장실1 베란다1.

◈ 매물 특징 ◈

*보증금: 4억9천만원 , 관리비: 미정.

* 21년식 도시형생활주택 풀옵션 2룸.

* 시스템에어컨2대,공기정화기,세탁기,냉장고,비데,인덕션 옵션.

* 엘리베이터 , cctv , 무인택배함.

* 빠른 입주 가능함.
',
'전세 4억 9,000','6층',2022,11,24,'서울시 강남구 논현동',2,'ssafy');